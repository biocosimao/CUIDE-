

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}


function mascararData(input) {
  let v = input.value.replace(/\D/g, '').slice(0, 8);
  if (v.length > 4) {
    v = v.replace(/(\d{2})(\d{2})(\d{0,4})/, '$1/$2/$3');
  } else if (v.length > 2) {
    v = v.replace(/(\d{2})(\d{0,2})/, '$1/$2');
  }
  input.value = v;
}


function definirSaudacaoPorHorario() {
  const elemento = document.getElementById('saudacao-horario');
  if (!elemento) return;

  const hora = new Date().getHours();
  let saudacao;
  if (hora >= 5 && hora < 12) {
    saudacao = 'Bom dia';
  } else if (hora >= 12 && hora < 18) {
    saudacao = 'Boa tarde';
  } else {
    saudacao = 'Boa noite';
  }
  elemento.textContent = saudacao;
}

document.addEventListener('DOMContentLoaded', definirSaudacaoPorHorario);


function abrirModalSintoma() {
  document.getElementById('modal-sintoma').style.display = 'flex';
}
function fecharModalSintoma() {
  document.getElementById('modal-sintoma').style.display = 'none';
  document.getElementById('input-sintoma-nome').value = '';
  document.getElementById('input-descricao').value = '';
  document.getElementById('input-intensidade').value = 5;
  document.getElementById('valor-intensidade').textContent = '5';
}

async function salvarSintoma() {
  const descricaoNome = document.getElementById('input-sintoma-nome').value.trim();
  if (!descricaoNome) {
    alert('Descreva o sintoma.');
    return;
  }
  const intensidade = document.getElementById('input-intensidade').value;
  const dataInicio = document.getElementById('input-data-inicio').value;
  const observacoes = document.getElementById('input-descricao').value.trim();

  const resp = await fetch('/api/sintomas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      descricao: descricaoNome,
      intensidade,
      data_inicio: dataInicio || null,
      observacoes,
    }),
  });
  if (resp.ok) {
    fecharModalSintoma();
    carregarSintomas();
    carregarRecomendacoesAplicaveis();
  } else {
    const erro = await resp.json();
    alert(erro.erro || 'Não foi possível registrar o sintoma.');
  }
}

async function excluirSintoma(id) {
  if (!confirm('Excluir este registro de sintoma?')) return;
  const resp = await fetch(`/api/sintomas/${id}`, { method: 'DELETE' });
  if (resp.ok) carregarSintomas();
}

function corIntensidade(n) {
  if (n <= 3) return 'leve';
  if (n <= 6) return 'moderado';
  return 'forte';
}

async function carregarSintomas() {
  const container = document.getElementById('lista-sintomas');
  if (!container) return;
  const resp = await fetch('/api/sintomas');
  const sintomas = await resp.json();

  if (!sintomas.length) {
    container.innerHTML = 'Nenhum sintoma registrado ainda.';
    return;
  }

  container.innerHTML = sintomas.map(s => `
    <div class="card-item">
      <div class="badge-intensidade ${corIntensidade(s.intensidade)}">${s.intensidade}</div>
      <div class="conteudo">
        <h4>${escapeHTML(s.descricao)}</h4>
        <small>${s.data_registro}${s.observacoes ? ' · ' + escapeHTML(s.observacoes) : ''}</small>
      </div>
      <button class="lixo" onclick="excluirSintoma(${s.id})"><i class="bi bi-trash"></i></button>
    </div>
  `).join('');
}

async function carregarRecomendacoesAplicaveis() {
  const container = document.getElementById('lista-recomendacoes-aplicaveis');
  if (!container) return;
  const resp = await fetch('/api/recomendacoes-aplicaveis');
  const lista = await resp.json();

  if (!lista.length) {
    container.innerHTML = 'Nenhuma recomendação cadastrada pelo hospital ainda.';
    return;
  }

  container.innerHTML = lista.map(r => {
    const pill = r.status === 'compativel'
      ? 'Aplicável'
      : ' Não aplicável';
    return `
      <div class="card-receita">
        <h4>${escapeHTML(r.titulo)}</h4>
        <div class="meta">${escapeHTML(r.profissional || '')} · código ${escapeHTML(r.codigo)}</div>
        <p>${escapeHTML(r.descricao)}</p>
        ${pill}
        <p style="margin-top:8px; color:#6b7280; font-size:13px;">${escapeHTML(r.motivo)}</p>
      </div>
    `;
  }).join('');
}

function organizarComIA() {
  alert('A organização por IA apenas resume e agrupa os sintomas já registrados — ela não sugere nem cria tratamentos. (Recurso em desenvolvimento neste protótipo.)');
}


async function carregarExemplo() {
  const input = document.getElementById('rx-code');
  const resp = await fetch('/api/recomendacoes-aplicaveis');
  const lista = await resp.json();
  if (lista.length) {
    input.value = lista[Math.floor(Math.random() * lista.length)].codigo;
  }
}

async function vincularReceita() {
  const input = document.getElementById('rx-code');
  const feedback = document.getElementById('rx-feedback');
  const codigo = input.value.trim();

  if (!codigo) {
    feedback.textContent = 'Informe o código da receita fornecido pelo hospital.';
    feedback.className = 'rx-feedback erro';
    return;
  }

  const resp = await fetch('/api/receitas/vincular', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ codigo }),
  });
  const dados = await resp.json();

  if (!resp.ok) {
    feedback.textContent = dados.erro || 'Não foi possível vincular esta receita.';
    feedback.className = 'rx-feedback erro';
    return;
  }

  feedback.textContent = dados.status === 'compativel'
    ? 'Receita vinculada e compatível com o seu histórico.'
    : 'Receita vinculada, mas marcada como incompatível — veja o motivo abaixo.';
  feedback.className = 'rx-feedback ' + (dados.status === 'compativel' ? 'ok' : 'erro');
  input.value = '';
  carregarReceitas();
}

async function iniciarReceita(vinculoId) {
  const hora = prompt('A que horas devemos lembrá-lo(a) de tomar?', '08:00');
  if (hora === null) return;
  const resp = await fetch(`/api/receitas/${vinculoId}/iniciar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ hora }),
  });
  if (resp.ok) {
    carregarReceitas();
  } else {
    const erro = await resp.json();
    alert(erro.erro || 'Não foi possível iniciar esta receita.');
  }
}

async function enviarParaFarmacia(receitaId) {
  const select = document.getElementById('farmacia-select-' + receitaId);
  const farmacia_id = select ? select.value : '';
  if (!farmacia_id) {
    alert('Escolha uma farmácia primeiro.');
    return;
  }
  const resp = await fetch(`/api/receitas/${receitaId}/enviar-farmacia`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ farmacia_id }),
  });
  if (resp.ok) {
    carregarReceitas();
  } else {
    const erro = await resp.json();
    alert(erro.erro || 'Não foi possível enviar a receita para a farmácia.');
  }
}

function pillPedidoFarmacia(pedido) {
  if (pedido.status === 'disponivel') {
    return `<span class="pill-disponivel">Disponível · ${Number(pedido.preco).toFixed(2)} Kz</span>`;
  }
  if (pedido.status === 'indisponivel') {
    return `<span class="pill-indisponivel">Indisponível</span>`;
  }
  return `<span class="pill-pendente">Aguardando resposta</span>`;
}

async function carregarReceitas() {
  const container = document.getElementById('lista-receitas');
  if (!container) return;
  const resp = await fetch('/api/receitas');
  const receitas = await resp.json();

  if (!receitas.length) {
    container.innerHTML = 'Nenhuma receita vinculada.';
    return;
  }

  const farmaciasResp = await fetch('/api/farmacias');
  const farmacias = await farmaciasResp.json();
  const opcoesFarmacia = farmacias.map(f => `<option value="${f.id}">${escapeHTML(f.nome)}</option>`).join('');

  container.innerHTML = receitas.map(r => {
    const rec = r.recomendacao || {};
    const pill = r.status === 'compativel'
      ? ' Compatibilidade verificada'
      : 'Incompatibilidade encontrada';

    const acao = r.status === 'compativel'
      ? (r.iniciada
          ? '<p class="em-andamento"><i class="bi bi-check-circle"></i> Em andamento — lembrete criado</p>'
          : `<button class="btn-iniciar" onclick="iniciarReceita(${r.id})"><i class="bi bi-play-fill"></i> Iniciar tratamento</button>`)
      : '';

    const envioFarmacia = r.status === 'compativel' && farmacias.length ? `
      <div class="farmacia-envio">
        <select id="farmacia-select-${r.id}">${opcoesFarmacia}</select>
        <button onclick="enviarParaFarmacia(${r.id})"><i class="bi bi-send"></i> Enviar para farmácia</button>
      </div>` : '';

    const pedidos = r.pedidos_farmacia || [];
    const listaPedidos = pedidos.length ? `
      <div class="pedidos-farmacia-lista">
        ${pedidos.map(pf => `
          <div class="pedido-farmacia-item">
            <i class="bi bi-shop"></i> ${escapeHTML(pf.farmacia || '')} — ${pillPedidoFarmacia(pf)}
          </div>
        `).join('')}
      </div>` : '';

    return `
      <div class="card-receita">
        <div class="codigo-badge">${escapeHTML(rec.codigo || '')}</div>
        <h4>${escapeHTML(rec.titulo || '')}</h4>
        <div class="meta">${escapeHTML(rec.profissional || 'Profissional do hospital')}</div>
        ${rec.posologia ? `<p>${escapeHTML(rec.posologia)}</p>` : ''}
        ${pill}
        <p style="margin-top:8px; color:#6b7280; font-size:13px;">${escapeHTML(r.motivo || '')}</p>
        ${acao}
        ${envioFarmacia}
        ${listaPedidos}
      </div>
    `;
  }).join('');
}


function abrirModalDiario() {
  document.getElementById('modal-diario').style.display = 'flex';
}
function fecharModalDiario() {
  document.getElementById('modal-diario').style.display = 'none';
}

async function salvarDiario() {
  const refeicao = document.getElementById('input-refeicao').value.trim();
  const agua = document.getElementById('input-agua').value || 0;
  const sono = document.getElementById('input-sono').value || 0;
  const comoSeSentiu = document.getElementById('input-como-se-sentiu').value.trim();

  const resp = await fetch('/api/diario', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      refeicao,
      agua_copos: agua,
      horas_sono: sono,
      como_se_sentiu: comoSeSentiu,
      alimentacao: refeicao,
    }),
  });
  if (resp.ok) {
    fecharModalDiario();
    document.getElementById('input-refeicao').value = '';
    document.getElementById('input-como-se-sentiu').value = '';
    carregarDiario();
  } else {
    alert('Não foi possível salvar o registro.');
  }
}

let periodoDiarioAtual = 'hoje';

function mudarPeriodo(periodo) {
  periodoDiarioAtual = periodo;
  const tabHoje = document.getElementById('tab-hoje');
  const tabSemana = document.getElementById('tab-semana');
  if (tabHoje && tabSemana) {
    tabHoje.classList.toggle('active-tempo', periodo === 'hoje');
    tabSemana.classList.toggle('active-tempo', periodo === 'semana');
  }
  carregarDiario();
}

async function carregarDiario() {
  const container = document.getElementById('lista-diario');
  if (!container) return;
  const resp = await fetch(`/api/diario?periodo=${periodoDiarioAtual}`);
  const registros = await resp.json();

  const aguaEl = document.getElementById('agua-hoje');
  const sonoEl = document.getElementById('sono-hoje');
  if (aguaEl && sonoEl) {
    if (registros.length) {
      const totalAgua = registros.reduce((soma, d) => soma + Number(d.agua_copos || 0), 0);
      const totalSono = registros.reduce((soma, d) => soma + Number(d.horas_sono || 0), 0);
      aguaEl.textContent = periodoDiarioAtual === 'semana' ? totalAgua : registros[0].agua_copos;
      sonoEl.textContent = periodoDiarioAtual === 'semana' ? totalSono : registros[0].horas_sono;
    } else {
      aguaEl.textContent = '0';
      sonoEl.textContent = '0';
    }
  }

  if (!registros.length) {
    container.innerHTML = '<div class="carde-registro"><p>Sem registros para o período.</p></div>';
    return;
  }

  container.innerHTML = registros.map(d => `
    <div class="carde-registro" style="height:auto; margin-bottom:10px;">
      <p><strong>${d.data}</strong> ${d.refeicao ? '· ' + escapeHTML(d.refeicao) : ''}</p>
      <p>💧 ${d.agua_copos} copos · 🌙 ${d.horas_sono}h ${d.como_se_sentiu ? '· sentiu-se: ' + escapeHTML(d.como_se_sentiu) : ''}</p>
    </div>
  `).join('');
}





async function marcarConsulta() {
  const hospital_id = document.getElementById('consulta-hospital').value;
  const data_hora = document.getElementById('consulta-data').value;
  const motivo = document.getElementById('consulta-motivo').value.trim();
  const tipoEl = document.querySelector('input[name="consulta-tipo"]:checked');
  const tipo = tipoEl ? tipoEl.value : 'presencial';
  const feedback = document.getElementById('consulta-feedback');

  if (!data_hora) {
    feedback.textContent = 'Escolha a data e hora da consulta.';
    feedback.className = 'rx-feedback erro';
    return;
  }

  const resp = await fetch('/api/consultas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ hospital_id, data_hora, motivo, tipo }),
  });

  if (resp.ok) {
    const dados = await resp.json();
    feedback.textContent = dados.tipo === 'online'
      ? 'Consulta online marcada! O link da sala já está disponível na sua lista.'
      : 'Consulta marcada com sucesso!';
    feedback.className = 'rx-feedback ok';
    document.getElementById('consulta-motivo').value = '';
    carregarConsultas();
  } else {
    const erro = await resp.json();
    feedback.textContent = erro.erro || 'Não foi possível marcar a consulta.';
    feedback.className = 'rx-feedback erro';
  }
}

async function carregarConsultas() {
  const container = document.getElementById('lista-consultas');
  if (!container) return;
  const resp = await fetch('/api/consultas');
  const consultas = await resp.json();

  if (!consultas.length) {
    container.innerHTML = '<p class="vazio">Nenhuma consulta marcada.</p>';
    return;
  }

  container.innerHTML = consultas.map(c => `
    <div class="card-item">
      <div class="conteudo">
        <h4>${escapeHTML(c.hospital || '')} ${c.tipo === 'online' ? '<span class="status-pill compativel"><i class="bi bi-camera-video"></i> Online</span>' : '<span class="status-pill" style="background:#e5e7eb;color:#374151;"><i class="bi bi-hospital"></i> Presencial</span>'}</h4>
        <small>${c.data_hora} · ${escapeHTML(c.status)}</small>
        <p>${escapeHTML(c.motivo || '')}</p>
        ${c.tipo === 'online' && c.link_online ? `<a href="${c.link_online}" target="_blank" style="color:#10b981; font-size:13px; font-weight:600;"><i class="bi bi-camera-video-fill"></i> Entrar na consulta online</a>` : ''}
      </div>
    </div>
  `).join('');
}
